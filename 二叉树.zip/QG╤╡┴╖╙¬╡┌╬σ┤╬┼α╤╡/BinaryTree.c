#include "LinkBiTree.h"

//����ն�����T
Status InitBiTree(BiTree T)
{
	T = NULL;
	return SUCCESS;
}

//�ݻٶ�����T
Status DestroyBiTree(BiTree T)
{
	if (T != NULL)
	{
		DestroyBiTree(T->lchild);
		DestroyBiTree(T->rchild);
		free(T);			//�ݻٽ��
	}
	return SUCCESS;
}

//�����幹�������T
Status CreateBiTree(BiTree *T, char* definition)
{
	flag++;
	if (definition[flag] == '#'|| definition[flag] == '\0')
	{
		*T = NULL;
		return SUCCESS;
	}
	else
	{
		*T = (BiTree)malloc(sizeof(BiTNode));
		if (!*T)
			return ERROR;
		(*T)->data = definition[flag];
		CreateBiTree(&(*T)->lchild, definition);
		CreateBiTree(&(*T)->rchild, definition);
	}
	return SUCCESS;
}

//�������
Status PreOrderTraverse(BiTree T, Status(*visit)(TElemType e))
{
	if (T != NULL)
	{
		visit(T->data);
		PreOrderTraverse(T->lchild, visit);
		PreOrderTraverse(T->rchild, visit);
	}
	return SUCCESS;
}

//�������
Status InOrderTraverse(BiTree T, Status(*visit)(TElemType e))
{
	if (T != NULL)
	{
		InOrderTraverse(T->lchild, visit);
		visit(T->data);
		InOrderTraverse(T->rchild, visit);
	}
	return SUCCESS;
}

//�������
Status PostOrderTraverse(BiTree T, Status(*visit)(TElemType e))
{
	if (T != NULL)
	{
		PostOrderTraverse(T->lchild, visit);
		PostOrderTraverse(T->rchild, visit);
		visit(T->data);
	}
	return SUCCESS;
}

//�������(��������ʵ��)
Status LevelOrderTraverse(BiTree T, Status(*visit)(TElemType e))
{
	TreeQueue Q;
	Q.front = Q.rear = 0;	//��ʼ��
	if (T == NULL)
		return;
	EnQueue(&Q, T);
	while (Q.front != Q.rear)
	{
		T = DeQueue(&Q);
		visit(T->data);
		if (T->lchild)
		{
			EnQueue(&Q, T->lchild);
		}
		if (T->rchild)
		{
			EnQueue(&Q, T->rchild);
		}
	}

}

//��ӡ����
Status visit(TElemType e)
{
	printf("%c",e);
	return SUCCESS;
}

//ǰ׺����ʽ�仯
char* CalCreat(char* s)
{
	char a[len];
	char* b;
	int i = 0, j = 0,k;
	for (i = 0; s[i] != '\0'; i++)
	{
		if (s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/')
		{
			a[j++] = s[i];
		}
		else if (s[i] >= '0' && s[i] <= '9')
		{
			a[j++] = s[i];
			for (k = 0; k < 2; k++)		//���Ҷ��ӽ�㶼Ӧ��Ϊ��
			{
				a[j++] = '#';
			}
		}
		
	}
	a[j] = '\0';
	b = a;
	return b;
}

//�������
int Caculate(int a, int b, char symbol)
{
	switch (symbol)
	{
	case '+':
		return a + b;
	case '-':
		return a - b;
	case '*':
		return a * b;
	case '/':
		return a / b;
	}
}

//��ֵ
int Value(BiTree T)
{
	if (T == NULL)
		return 0;
	int left, right;
	left = Value(T->lchild);
	right = Value(T->rchild);
	if (T->lchild == NULL && T->rchild == NULL)
		return T->data - '0';
	else
	{
		return Caculate(left, right, T->data);
	}
}

//��ӱ�����
void EnQueue(TreeQueue* Q, BiTree T)
{
	if (Q->rear == len)
		return;
	else
	{
		Q->data[Q->rear] = T;
		Q->rear++;
	}
}

//����
BiTree DeQueue(TreeQueue* Q)
{
	if (Q->front == Q->rear)
	{
		return NULL;
	}
	else
	{
		Q->front++;
		return Q->data[Q->front - 1];
	}
}








