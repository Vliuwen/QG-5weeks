#include"LQueue.h"
//��ʼ������
void InitLQueue(LQueue* Q)
{
	Node* p = (Node*)malloc(sizeof(Node));
	if (NULL == p)
		return;
	p->next = NULL;
	Q->front =p;
	Q->rear = p;
	return;
}

//���ٶ���
void DestoryLQueue(LQueue* Q)
{
	if (IsEmptyLQueue(Q))
		return;
	ClearLQueue(Q);
	free(Q->rear);
	printf("���ٳɹ�\n");
}

//�������Ƿ�Ϊ��
Status IsEmptyLQueue(const LQueue* Q)
{
	return (Q->front == Q->rear ? TRUE : FALSE);
}

//�鿴��ͷԪ��
Status GetHeadLQueue(LQueue* Q, void* e)
{
	if (IsEmptyLQueue(Q))
		return FALSE;
	if (Q->front->next->size == 'd')
		memcpy(e, Q->front->next->data, sizeof(int));
	else if (Q->front->next->size == 'f')
		memcpy(e, Q->front->next->data, sizeof(double));
	else if (Q->front->next->size == 'c')
		memcpy(e, Q->front->next->data, sizeof(char));
		return TRUE;
}

//��ն��� 
void ClearLQueue(LQueue *Q)
{
	if(IsEmptyLQueue(Q))
		return;
	Node* p, * q;
	Q->rear = Q->front;
	p = Q->front->next;
	while (p != NULL) {
		q = p;
		p = p->next;
		free(q);
	}
	free(p);
	printf("��ճɹ�!\n");
	return;



} 



//ȷ�����г���
int LengthLQueue(LQueue* Q)
{
	int length;
	Node* p = (Node*)malloc(sizeof(Node));
	p = Q->front;
	for (length = 0; p != Q->rear; length++)
		p = p->next;
	return length;
}


void setDataType(LQueue* Q)
{

	int a;
	printf("��ѡ���������ݵ��������ͣ�\n");
	printf("1.���� 2.������ 3.�ַ��� \n");
	scanf("%d", &a);
	printf("�����뽫��ӵ����ݣ�");
	switch (a)
	{
	case 1: {
		int b;
		scanf("%d", &b);
		EnLQueue(Q, &b);
		Q->rear->size = 'd';
		break;
	}
	case 2: {
		double b;
		scanf("%lf", &b);
		EnLQueue(Q, &b);
		Q->rear->size = 'f';
		break;
	}
	case 3: {
		getchar();
		char b;
		scanf("%c", &b);
		EnLQueue(Q, &b);
		Q->rear->size = 'c';
		break;
	}
	}
}

//���
Status EnLQueue(LQueue* Q, void* data)
{
	Node* p = (Node*)malloc(sizeof(Node));
	if (p == NULL)
		return FALSE;
	p->data = (void*)malloc(20);
	memcpy(p->data,data,20);
	p->next = NULL;
	Q->rear->next = p;
	Q->rear = p;
	return TRUE;
}

//����
Status DeLQueue(LQueue* Q)
{
	if (IsEmptyLQueue(Q))
	return FALSE;
	Node* p = (Node*)malloc(sizeof(Node));
	p = Q->front->next;
	Q->front->next = p->next;
	if (Q->front->next == NULL)
		Q->rear = Q->front;
	free(p);
	printf("���ӳɹ���\n");
	return TRUE;
}

//������������
Status TraverseLQueue(const LQueue* Q, void (*foo)(void* q,char size))
{
	if (IsEmptyLQueue(Q))
		return FALSE;
	Node* p = (Node*)malloc(sizeof(Node));
	p = Q->front->next;
	while (p!=NULL)
	{
		foo(p->data, p->size);
		p = p->next;
	}
	printf("\n");
	return TRUE;

}

//��������
void LPrint(void* q,char size)
{
	if (size == 'd')
		printf("%d ", *(int*)q);
	if (size == 'c')
		printf("%c ", *(char*)q);
	if (size == 'f')
		printf("%lf ", *(double*)q);
}
