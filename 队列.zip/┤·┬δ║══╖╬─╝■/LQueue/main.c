#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"LQueue.c"

int main()
{
	int i;
	void (*p)(void* q, char size);
	LQueue *Q=(LQueue*)malloc(sizeof(LQueue));
	InitLQueue(Q);
	if (IsEmptyLQueue(Q))
		printf("�����ѿգ�\n");
	for (i = 0; i < 3; i++)
	{
		setDataType(Q);
	}
	printf("���еĳ���Ϊ:%d\n",LengthLQueue(Q));
	
	switch (Q->front->next->size)
	{
	case 'd': {
		int a;
		GetHeadLQueue(Q, &a);
		printf("����ͷԪ��Ϊ%d \n", a);
		break;
	}
	case 'c': {
		char a;
		GetHeadLQueue(Q, &a);
		printf("����ͷԪ��Ϊ%c \n", a);
		break;
	}
	case 'f': {
		double a;
		GetHeadLQueue(Q, &a);
		printf("����ͷԪ��Ϊ%lf \n", a);
		break;
	}
	}
	p = LPrint;
	TraverseLQueue(Q, p);
	DeLQueue(Q);
	DestoryLQueue(Q);
	getchar();
	return 0;

}
