#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"AQueue.c"

int main()
{	
	int i;
	void (*p)(void *q,char type);
	AQueue* Q = (AQueue*)malloc(sizeof(AQueue));
	InitAQueue(Q);
	if (IsEmptyAQueue(Q))
		printf("�����ѿ�\n");
	for (i = 0; i < MAXQUEUE-1; i++)
	{	
		setDataType(Q);
	}
	if (IsFullAQueue(Q))
		printf("����������\n");
	DeAQueue(Q);
	printf("���г���Ϊ��%d\n", LengthAQueue(Q));
	
	switch (datatype[Q->front])
	{
	case 'd':{
		int a;
		GetHeadAQueue(Q, &a);
		printf("����ͷԪ��Ϊ%d \n", (int)a);
		break;
	}
	case 'c':{
		char a;
		GetHeadAQueue(Q, &a);
		printf("����ͷԪ��Ϊ%c \n", (char)a);
		break;
	}
	case 'f':{
		double a;
		GetHeadAQueue(Q, &a);
		printf("����ͷԪ��Ϊ%lf \n", (double)a);
		break;
	}
	case 's':{
		char a[20];
		GetHeadAQueue(Q, &a);
		printf("����ͷԪ��Ϊ%s \n", (char*)a);
		break;
	}
	}
	printf("\n");
	p=APrint;
	TraverseAQueue(Q, p);
	ClearAQueue(Q);
	DestoryAQueue(Q);
	getchar(); 
	return 0;





}
