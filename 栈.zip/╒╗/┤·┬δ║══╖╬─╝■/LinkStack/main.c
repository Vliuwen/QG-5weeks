#include <stdio.h>
#include <stdlib.h>
#include "LinkStack.c"

int main()
{
	LinkStack s;
	ElemType tmp;
	int length;
	initLStack(&s);
	pushLStack(&s, 5);
	pushLStack(&s, 7);
	pushLStack(&s, 34);
	pushLStack(&s, 65);
	pushLStack(&s, 23);
	pushLStack(&s, 55);
	popLStack(&s, &tmp);
	printf("��ջ��Ԫ��Ϊ��%d\n", tmp);
	popLStack(&s, &tmp);
	LStackLength(&s, &length);
	printf("ջ����Ϊ%d\n", length);
	getTopLStack(&s, &tmp);
	printf("ջ��Ԫ��Ϊ%d", tmp);
	destroyLStack(&s);
	return 0;



}