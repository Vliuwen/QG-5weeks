#include<stdio.h>
#include<stdlib.h>
int main()
{   
    int i;
	FILE* fp;
	int* a = (int*)malloc(sizeof(int) * 10000);
    int* b = (int*)malloc(sizeof(int) * 50000);
    int* c = (int*)malloc(sizeof(int) * 200000);
    if ((fp = fopen("Output.txt", "w+")) == NULL)
    {
        printf("�޷��򿪸��ļ���\n");
        exit(0);
    }
    for (i = 0; i < 10000; i++)
    {
        a[i] = rand();
        fprintf(fp, "%d\t", a[i]);
    }
    for (i = 0; i < 50000; i++)
    {
        b[i] = rand();
        fprintf(fp, "%d\t", b[i]);
    }
    for (i = 0; i < 200000; i++)
    {
        c[i] = rand();
        fprintf(fp, "%d\t", c[i]);
    }
    fclose(fp);
    printf("���ɳɹ���\n");
} 
